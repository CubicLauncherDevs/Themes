#!/usr/bin/env python3
"""Generate theme.json colors based on the dominant palette of bg.png."""

import json
import math
import os
import sys
from collections import Counter

from PIL import Image

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def luminance(r, g, b):
    return 0.299 * r + 0.587 * g + 0.114 * b


def rgb_to_hex(r, g, b):
    return f"#{r:02x}{g:02x}{b:02x}"


def rgba(r, g, b, a):
    return f"rgba({r},{g},{b},{a})"


def clamp(v, lo=0, hi=255):
    return max(lo, min(hi, v))


def lerp(a, b, t):
    return a + (b - a) * t


def mix_color(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


# ---------------------------------------------------------------------------
# image analysis
# ---------------------------------------------------------------------------

def analyze_image(path):
    img = Image.open(path).convert("RGB")
    w, h = img.size
    pixels = list(img.getdata())
    n = len(pixels)

    # --- brightness distribution ---
    lumas = [luminance(*p) for p in pixels]

    # sort by luminance
    sorted_px = sorted(pixels, key=lambda rgb: luminance(*rgb))

    def avg_sample(fraction_from_dark):
        idx = int(n * fraction_from_dark)
        idx = max(0, min(n - 1, idx))
        return sorted_px[idx]

    # key reference points (5 % / 25 % / 50 % / 75 % / 95 %)
    dark5 = avg_sample(0.05)
    q25 = avg_sample(0.25)
    median = avg_sample(0.50)
    q75 = avg_sample(0.75)
    bright5 = avg_sample(0.95)

    # average of the whole image
    avg_r = sum(p[0] for p in pixels) // n
    avg_g = sum(p[1] for p in pixels) // n
    avg_b = sum(p[2] for p in pixels) // n
    avg = (avg_r, avg_g, avg_b)

    # average of edges (border region)
    edge_samples = []
    step = max(1, w // 200)  # sample edges sparsely
    for x in range(0, w, step):
        edge_samples.append(img.getpixel((x, 0)))
        edge_samples.append(img.getpixel((x, h - 1)))
    for y in range(1, h - 1, step):
        edge_samples.append(img.getpixel((0, y)))
        edge_samples.append(img.getpixel((w - 1, y)))
    edge_avg = (
        sum(p[0] for p in edge_samples) // len(edge_samples),
        sum(p[1] for p in edge_samples) // len(edge_samples),
        sum(p[2] for p in edge_samples) // len(edge_samples),
    )

    return {
        "dark5": dark5,
        "q25": q25,
        "median": median,
        "q75": q75,
        "bright5": bright5,
        "avg": avg,
        "edge_avg": edge_avg,
        "lumas": lumas,
        "w": w,
        "h": h,
    }


# ---------------------------------------------------------------------------
# palette generation
# ---------------------------------------------------------------------------

def make_palette(info, accent_hue=25):
    """
    accent_hue: 0-360 – 25 is a warm orange (Lain-ish).
    """
    d5 = info["dark5"]
    q25 = info["q25"]
    med = info["median"]
    q75 = info["q75"]
    b5 = info["bright5"]
    avg = info["avg"]
    edge = info["edge_avg"]

    # ---- background surfaces ----
    # Derive from the darkest parts of the image
    bg_main = rgb_to_hex(*d5)
    # Sidebar: push toward pure black
    bg_sidebar = rgb_to_hex(*mix_color(d5, (0, 0, 0), 0.4))
    # Cards: between q25 and median
    bg_card = rgb_to_hex(*mix_color(q25, med, 0.5))
    # Item active: similar to card
    bg_item_active = rgb_to_hex(*mix_color(q25, med, 0.5))
    # Overlay: use a dark tone from q25
    bg_overlay = rgba(*mix_color(d5, (0, 0, 0), 0.5), 0.78)
    # Input: between q25 and median
    bg_input = rgb_to_hex(*mix_color(q25, med, 0.3))

    # ---- text ----
    text_primary = rgb_to_hex(*mix_color(b5, (255, 255, 255), 0.3))
    text_secondary = rgb_to_hex(*(255, 255, 255))
    text_muted = rgb_to_hex(*mix_color(q75, edge, 0.5))
    # text-accent will use the accent color

    # ---- accent colour (HSL-based) ----
    # Convert accent_hue to RGB fully saturated, then tone it down
    def hsl_to_rgb(h, s, l):
        h = h / 360
        s = s / 100
        l = l / 100
        if s == 0:
            return (int(l * 255),) * 3
        def hue2rgb(p, q, t):
            if t < 0:
                t += 1
            if t > 1:
                t -= 1
            if t < 1 / 6:
                return p + (q - p) * 6 * t
            if t < 1 / 2:
                return q
            if t < 2 / 3:
                return p + (q - p) * (2 / 3 - t) * 6
            return p
        q = l * (1 + s) if l < 0.5 else l + s - l * s
        p = 2 * l - q
        return (
            int(hue2rgb(p, q, h + 1 / 3) * 255),
            int(hue2rgb(p, q, h) * 255),
            int(hue2rgb(p, q, h - 1 / 3) * 255),
        )

    accent = hsl_to_rgb(accent_hue, 85, 55)
    accent_hover = hsl_to_rgb(accent_hue, 85, 50)
    accent_active = hsl_to_rgb(accent_hue, 70, 55)
    accent_text = hsl_to_rgb(accent_hue, 20, 10)

    text_accent = rgb_to_hex(*accent)

    # ---- borders ----
    border_color = rgb_to_hex(*mix_color(edge, (0, 0, 0), 0.7))
    border_hover_rgb = mix_color(accent, d5, 0.6)
    border_hover = rgb_to_hex(*border_hover_rgb)

    # ---- status colours (keep fixed – semantic) ----
    success = (114, 196, 126)
    error = (232, 96, 96)
    warning = (232, 176, 64)
    info = (106, 174, 212)

    # ---- shadows ----
    shadow_sm = "0 1px 3px rgba(0,0,0,0.6)"
    shadow_md = "0 4px 14px rgba(0,0,0,0.7)"
    shadow_lg = "0 8px 28px rgba(0,0,0,0.75)"
    glow_accent = f"0 0 16px rgba({accent[0]},{accent[1]},{accent[2]},0.22)"
    glow_accent_strong = f"0 0 28px rgba({accent[0]},{accent[1]},{accent[2]},0.38)"

    # ---- scrollbar ----
    scroll_track = rgb_to_hex(*mix_color(d5, (0, 0, 0), 0.3))
    scroll_thumb = rgb_to_hex(*mix_color(q25, q75, 0.3))
    scroll_thumb_hover = rgb_to_hex(*mix_color(border_hover_rgb, q75, 0.5))

    # ---- icon filters (keep generic, adjust for accent) ----
    def icon_filter(r, g, b):
        # approximate CSS filter that would produce this colour from white
        # We'll just keep the existing approach: hardcoded filters.
        # For dynamic generation, we return a placeholder.
        return None

    rotate = (accent_hue - 340) % 360
    icon_filter_accent = (
        f"invert(70%) sepia(60%) saturate(800%) hue-rotate({rotate}deg) brightness(105%)"
    )

    # ---- brightness-based adjustments ----
    avg_lum = luminance(*avg)
    is_dark = avg_lum < 100

    # ---- assemble result ----
    return {
        "--bg-main": bg_main,
        "--bg-sidebar": bg_sidebar,
        "--bg-card": bg_card,
        "--bg-item-active": bg_item_active,
        "--bg-overlay": bg_overlay,
        "--bg-input": bg_input,
        "--text-primary": text_primary,
        "--text-secondary": text_secondary,
        "--text-muted": text_muted,
        "--text-accent": text_accent,
        "--border-color": border_color,
        "--border-color-hover": border_hover,
        "--border-radius": "5px",
        "--border-radius-sm": "2px",
        "--border-radius-lg": "8px",
        "--accent": text_accent,
        "--accent-rgb": f"{accent[0]},{accent[1]},{accent[2]}",
        "--accent-hover": rgb_to_hex(*accent_hover),
        "--accent-active": rgb_to_hex(*accent_active),
        "--accent-text": rgb_to_hex(*accent_text),
        "--accent-subtle": rgba(*accent, 0.08),
        "--shadow-sm": shadow_sm,
        "--shadow-md": shadow_md,
        "--shadow-lg": shadow_lg,
        "--glow-accent": glow_accent,
        "--glow-accent-strong": glow_accent_strong,
        "--color-success": rgb_to_hex(*success),
        "--color-success-rgb": f"{success[0]},{success[1]},{success[2]}",
        "--color-error": rgb_to_hex(*error),
        "--color-error-rgb": f"{error[0]},{error[1]},{error[2]}",
        "--color-warning": rgb_to_hex(*warning),
        "--color-warning-rgb": f"{warning[0]},{warning[1]},{warning[2]}",
        "--color-info": rgb_to_hex(*info),
        "--color-info-rgb": f"{info[0]},{info[1]},{info[2]}",
        "--color-status-starting": rgb_to_hex(*accent_active),
        "--color-status-started": rgb_to_hex(*success),
        "--color-status-stopped": rgb_to_hex(*mix_color(q25, (0, 0, 0), 0.5)),
        "--color-status-error": rgb_to_hex(*error),
        "--icon-filter": "invert(85%) sepia(15%) saturate(400%) hue-rotate(340deg) brightness(95%)" if is_dark else "invert(40%) sepia(10%) saturate(300%) hue-rotate(0deg) brightness(90%)",
        "--icon-filter-accent": icon_filter_accent,
        "--icon-filter-success": "invert(65%) sepia(40%) saturate(600%) hue-rotate(90deg) brightness(105%)",
        "--icon-filter-error": "invert(45%) sepia(80%) saturate(4000%) hue-rotate(340deg) brightness(100%)",
        "--icon-filter-warning": "invert(70%) sepia(70%) saturate(700%) hue-rotate(5deg) brightness(108%)",
        "--icon-filter-info": "invert(65%) sepia(30%) saturate(600%) hue-rotate(180deg) brightness(110%)",
        "--icon-filter-muted": "invert(35%) sepia(10%) saturate(300%) hue-rotate(340deg) brightness(80%)",
        "--scrollbar-track": scroll_track,
        "--scrollbar-thumb": scroll_thumb,
        "--scrollbar-thumb-hover": scroll_thumb_hover,
        "--font-family": "Cantarell, sans-serif",
        "--font-size-base": "14px",
        "--font-size-sm": "12px",
        "--font-size-lg": "16px",
        "--bg-image": "none",
        "--bg-image-blur": "0px",
        "--bg-image-opacity": "1",
        "--transition-fast": "0.12s ease",
        "--transition-base": "0.2s ease",
        "--transition-slow": "0.35s ease",
    }


# ---------------------------------------------------------------------------
# write theme.json
# ---------------------------------------------------------------------------

def write_theme(variables, output_path):
    theme = {
        "$schema": "https://raw.githubusercontent.com/CubicLauncher/Themes/refs/heads/main/theme-schema.json",
        "name": "Lain Theme",
        "author": "notstaff",
        "type": "user",
        "font": "font",
        "bg_image": "bg.jpg",
        "variables": variables,
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(theme, f, indent=2)
        f.write("\n")


# ---------------------------------------------------------------------------
# cli entry point
# ---------------------------------------------------------------------------

def main():
    bg_path = os.path.join(SCRIPT_DIR, "bg.png")
    theme_path = os.path.join(SCRIPT_DIR, "theme.json")

    if not os.path.isfile(bg_path):
        print(f"Error: {bg_path} not found", file=sys.stderr)
        sys.exit(1)

    print(f"Analysing {bg_path} …")
    info = analyze_image(bg_path)

    # detectable accent from image (if any colour is present)
    # For purely grayscale images we default to a warm orange.
    accent_hue = 25
    info_lum = info["avg"]
    if max(info_lum) - min(info_lum) > 10:
        # crude hue detection via dominant colourful pixel
        from collections import Counter as Ctr
        px = list(Image.open(bg_path).convert("RGB").getdata())
        colourful = [(r, g, b) for r, g, b in px if max(r, g, b) - min(r, g, b) > 30]
        if colourful:
            import colorsys
            top = Ctr(colourful).most_common(1)[0][0]
            h, s, v = colorsys.rgb_to_hsv(top[0] / 255, top[1] / 255, top[2] / 255)
            if s > 0.15:
                accent_hue = int(h * 360)

    print(f"Accent hue: {accent_hue}°")
    print(f"Image avg luminance: {luminance(*info_lum):.0f} / 255")

    variables = make_palette(info, accent_hue=accent_hue)

    print(f"Writing {theme_path} …")
    write_theme(variables, theme_path)

    # Show a summary of generated colors
    for key in ("--bg-main", "--bg-card", "--text-primary", "--text-accent", "--accent"):
        print(f"  {key}: {variables[key]}")

    print("Done.")


if __name__ == "__main__":
    main()
